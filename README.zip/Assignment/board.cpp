#include <iostream>
using namespace std;

// Functions:
void displayMenu()
{
    system("cls");
    cout << "________________________" << endl;
    cout << "|   Alien vs. Zombie   |" << endl;
    cout << "|----------------------|" << endl;
    cout << "| Select:              |" << endl;
    cout << "| 1 => Start Game      |" << endl;
    cout << "| 2 => Settings        |" << endl;
    cout << "|----------------------|" << endl;
    cout << "| Q => Quit            |" << endl;
    cout << "|______________________|" << endl;
    cout << endl;

    cout << "Choice => ";
}


void displayDefaultSetting(int rows, int columns, int zombie)
{
    cout << "Default Game Settings" << endl;
    cout << "---------------------" << endl;
    cout << "Board Rows         : " << rows << endl;
    cout << "Board Columns      : " << columns << endl;
    cout << "Zombie Count       : " << zombie << endl;

    cout << "Do you wish to change the game settings (y/n)? => ";
    cin >> choose;
    if (choose == "y")
    {
                
    }
}

void displayChangeSetting(int rows, int columns, int zombie)
{
    cout << "Change Game Settings " << endl;
    cout << "---------------------" << endl;
    cout << "Board Rows         : " ;
    cin >> rows;
    cout << "Board Columns      : "  ;
    cin >> columns;
    cout << "Zombie Count       : "  ;
    cin >> zombie;
}

void displayGame(int rows, int columns, int zombie)
{
    cout << "hello!"<< endl;
}

int main()
{
    int rows = 5;
    int columns = 9;
    int zombie = 1;
    char choice; 
    char choose;
    bool done = false;
    do
    {
        displayMenu();
        cin >> choice;
        choice = toupper(choice);
        cout << endl;
        switch (choice)
        {
        case '1':
            displayGame(rows, columns, zombie);
            break; 
        case '2':
            displayDefaultSetting(rows, columns, zombie);
            cin >> choose;
            if (choose == 'y')
            {
                displayChangeSetting(rows, columns, zombie);
                break;
            }
            else if (choose == 'n')
            {
                displayMenu();
            }
            else
            {
                cout << "Invalid selection, try again!" << endl; 
                cout << endl;
                break;
            }
            break;
        case 'Q':
            done = true;
            cout << "GOOD BYE!!" <<endl;
            break;
        default:
            cout << "Invalid selection, try again!" << endl; 
            cout << endl;
            break;
        }
        system("pause");
    } while (!done);
}