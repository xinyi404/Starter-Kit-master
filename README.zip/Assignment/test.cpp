#include "helper.h"
#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;
using namespace pf;

// class board:
class Board
{
private:
    vector<vector<char>> map_;
    int dimX_, dimY_;

public:
    Board(int dimX_ = 15, int dimY_ = 5);
    void init(int dimX, int dimY);
    void display();
    int getDimX() const;
    int getDimY() const;
    char getObject(int x, int y) const;
    void setObject(int x, int y, char ch);
};

int Board::getDimX() const
{
    return dimX_;
}

int Board::getDimY() const
{
    return dimY_;
}

Board::Board(int dimX, int dimY)
{
    init(dimX, dimY);
}

void Board::init(int dimX, int dimY)
{
    dimX_ = dimX;
    dimY_ = dimY;
    char objects[] = {' ', ' ', ' ', ' ', ' ', ' ', 'h', '>', 'r', 'p', '<', '^', 'v'};
    int noOfObjects = 13; // number of objects in the objects array
    // create dynamic 2D array using vector
    map_.resize(dimY_); // create empty rows
    for (int i = 0; i < dimY_; ++i)
    {
        map_[i].resize(dimX_); // resize each row
    }
    // put random characters into the vector array
    for (int i = 0; i < dimY_; ++i)
    {
        for (int j = 0; j < dimX_; ++j)
        {
            int objNo = rand() % noOfObjects;
            map_[i][j] = objects[objNo];
        }
    }
}

void Board::display()
{
    // comment this out during testing
    // system("cls"); // OR system("clear"); for Linux / MacOS
    cout << " -------------------------------" << endl;
    cout << " =        Alien VS Zombie      =" << endl;
    cout << " -------------------------------" << endl;
    // for each row
    for (int i = 0; i < dimY_; ++i)
    {
        // display upper border of the row
        cout << "  ";
        for (int j = 0; j < dimX_; ++j)
        {
            cout << "+-";
        }
        cout << "+" << endl;
        // display row number
        cout << setw(2) << (i + 1);
        // display cell content and border of each column
        for (int j = 0; j < dimX_; ++j)
        {
            cout << "|" << map_[i][j];
        }
        cout << "|" << endl;
    }
    // display lower border of the last row
    cout << "  ";
    for (int j = 0; j < dimX_; ++j)
    {
        cout << "+-";
    }
    cout << "+" << endl;
    // display column number
    cout << "  ";
    for (int j = 0; j < dimX_; ++j)
    {
        int digit = (j + 1) / 10;
        cout << " ";
        if (digit == 0)
            cout << " ";
        else
            cout << digit;
    }
    cout << endl;
    cout << "  ";
    for (int j = 0; j < dimX_; ++j) // j==0...14
    {
        cout << " " << (j + 1) % 10;
    }
    cout << endl
         << endl;
}

char Board::getObject(int x, int y) const
{
    return map_[-(y - 5)][x - 1];
}

void Board::setObject(int x, int y, char ch)
{
    map_[-(y - 5)][x - 1] = ch;
}

void displayGame()
{
    Board board;
    board.display();
}

// Functions:
void displayMenu()
{
    system("cls");
    cout << " _______________________" << endl;
    cout << "|   Alien vs. Zombie   |" << endl;
    cout << "|----------------------|" << endl;
    cout << "| Select:              |" << endl;
    cout << "| 1 => Start Game      |" << endl;
    cout << "| 2 => Settings        |" << endl;
    cout << "|----------------------|" << endl;
    cout << "| Q => Quit            |" << endl;
    cout << "|______________________|" << endl;
    cout << endl;

    cout << "Choice => ";
}

void displayDefaultSetting(int &rows, int &columns, int &zombie)
{
    cout << "Default Game Settings" << endl;
    cout << "---------------------" << endl;
    cout << "Board Rows        : " << rows << endl;
    cout << "Board Columns     : " << columns << endl;
    cout << "Zombie Count      : " << zombie << endl;

    cout << "Do you wish to change the game settings (y/n)? => ";
}
int newSetting(int &rows ,int &columns, int &zombie)
{
    cout << "Change Board Settings " << endl;
    cout << "---------------------" << endl;
    //rows
    do
    {
        cout << "Enter Rows        : ";
        cin >> rows;
        if (rows % 2 == 0 || rows < 3)
            cout << "Try enter odd integer > 2 instead!!" << endl;

    } while (rows % 2 == 0 || rows < 3);
    //columns
    do
    {
        cout << "Enter Columns        : ";
        cin >> columns;
        if (columns % 2 == 0 || columns < 3)
            cout << "Try enter odd integer > 2 instead!!" << endl;

    } while (columns % 2 == 0 || columns < 3);
    //zombie
    cout << "Change Zombie Settings   " << endl;
    cout << "-------------------------" << endl;
    do
    {
        cout << "Enter number of zombie        : ";
        cin >> zombie;
        if (zombie < 1 || zombie > 10)
            cout << "Try enter integer in range 1 to 9" << endl;

    } while (zombie < 1 || zombie > 10);
    return rows, columns, zombie;
}


// main
int main()
{
    int rows = 5;
    int columns = 9;
    int zombie = 1;
    char choice;
    char choose;
    bool done = false;
    do
    {
        // srand(time(NULL));
        displayMenu();
        cin >> choice;
        choice = toupper(choice);
        cout << endl;
        switch (choice)
        {
        case '1':
            // srand(time(NULL));
            displayGame();
            int ClearScreen();
            break;
        case '2':
            displayDefaultSetting(rows, columns, zombie);
            cin >> choose;
            cout << endl;
            int ClearScreen();

            if (choose == 'y')
            {
                newSetting(rows, columns, zombie);
                cout << "Settings Updated. " << endl;
                cout << endl;
                // srand(time(NULL));
                displayGame();
            }
            else if (choose == 'n')
            {
                cout << endl;
                cout << "Game Loading..." << endl;
                cout << endl;
                // srand(time(NULL));
                displayGame();
            }
            else
            {
                cout << "Invalid selection, try again!" << endl;
                cout << endl;
                break;
            }
            break;
        case 'Q':
            done = true;
            cout << "GOOD BYE!!" << endl;
            break;
        default:
            cout << "Invalid selection, try again!" << endl;
            cout << endl;
            break;
        }
        system("pause");
    } while (!done);
}