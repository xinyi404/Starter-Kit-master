#ifndef PF_HELPER_H
#define PF_HELPER_H

namespace pf
{
    int ClearScreen();
    int Pause();

    void CreateGameBoard();
    void ShowGameBoard();
}

#endif