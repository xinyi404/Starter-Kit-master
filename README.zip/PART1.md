# Part 1

## Video Demo

Please provide the YouTube link to your [Video Demo](https://youtube.com).

## Minimum Requirements

### Completed

List all the features completed.

1. Cool Feature #1
2. Cool Feature #2
3. *add more*

### To Do

List all the features not yet done. Remove this section if there is no incomplete requirements.

1. Cool Feature #1
2. *add more*

## Additional Features

Describe the additional features that has been implemented.

## Contributions

List down the contribution of each group members.

For example:

### Tony Stark

1. Randomly generate game board.
2. *add more*

### Steve Rogers

1. Zombie movement and attack behaviour.
2. *add more*

### Dr. Strange

1. Implement all game objects.
2. *add more*

## Problems Encountered & Solutions

Describe the problems encountered and provide the solutions / plan for the solutions.